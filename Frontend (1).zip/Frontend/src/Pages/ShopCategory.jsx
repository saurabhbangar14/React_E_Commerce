import React, { useContext, useState } from "react";
import "./CSS/ShopCategory.css";
import { ShopContext } from "../Context/ShopContext";
import dropdown_icon from "../Components/Assets/dropdown_icon.png";
import Item from "../Components/Item/Item";
import SortDropdown from "../Components/SortDropdown/SortDropdown";

const ShopCategory = (props) => {
 const { all_product, sortOption } = useContext(ShopContext);
//  console.log("ShopCategory all product", all_product)
 const [isDropdownVisible, setIsDropdownVisible] = useState(false);

 const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
 };

 const sortProducts = (products, sortOption) => {
    let sortedProducts = [...products];

    switch (sortOption) {
      case "By Name":
        sortedProducts.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "By Low to High":
        sortedProducts.sort((a, b) => a.new_price - b.new_price);
        break;
      case "By High to Low":
        sortedProducts.sort((a, b) => b.new_price - a.new_price);
        break;
      default:
        break;
    }
    return sortedProducts;
 };

 const sortedProducts = sortProducts(all_product, sortOption);

 return (
    <div className="shop-category">
      <img className="shopcategory-banner" src={props.banner} alt="" />
      <div className="shopcategory-indexSort">
        <p>
          <span>Showing 1-12</span> out of 36 products
        </p>
        <div className="shopcategory-sort" onClick={toggleDropdown}>
          Sort by <img src={dropdown_icon} alt="" />
          {isDropdownVisible && <SortDropdown />}
        </div>
      </div>
      <div className="shopcategory-products">
        {sortedProducts.map((item) => {
          if (props.category === item.cat) {
            return (
              <Item
                key={item.id}
                id={item.id}
                name={item.title}
                image={item.img}
                new_price={item.new_price}
                old_price={item.old_price}
              />
            );
          } else {
            return null;
          }
        })}
      </div>
      <div className="shopcategory-loadmore">Explore More</div>
    </div>
 );
};

export default ShopCategory;
