import React, { useState, useContext } from "react";
import {  useNavigate } from "react-router-dom";
import "./CSS/LoginSignup.css";
import { AuthContext } from "../Context/authContext";
import axios from "axios";

const LoginSignup = (prop) => {
  const [state, setState] = useState(prop.check);
  const [logininputs, setloginInputs] = useState({
    username: "",
    password: "",
  });

  const { login } = useContext(AuthContext);

  const [inputs, setInputs] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [err, setError] = useState(null);

  const navigate = useNavigate();
  const handleChange = (e) => {
    if (state === "Sign Up") {
      setInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    } else {
      setloginInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (state === "Sign Up") {
      try {
        const res=await axios.post(
          "http://localhost:3000/api/auth/register",
          inputs
        );
        setState("Login");
      } catch (err) {
        console.log(err.response.data.message)
        setError(err.response.data.message);
      }
    } else {
      try {

        const res=await login(logininputs);
        navigate("/");
      } catch (err) {
        console.log("==err",err.response.data.message)
        setError(err.response.data.message);
      }
    }
  };
console.log(err)
  return (
    <div className="loginsignup">
      <div className="loginsignup-container">
        <h1>{state}</h1>
        <div className="loginsignup-fields">
          {state === "Sign Up" ? (
            <input
              type="Email"
              placeholder="Enter Email"
              name="email"
              onChange={handleChange}
            />
          ) : (
            <></>
          )}
          <input
            type="text"
            placeholder="Enter username"
            name="username"
            onChange={handleChange}
          />
          <input
            type="password"
            placeholder="Enter Password"
            name="password"
            onChange={handleChange}
          />
        </div>
        <div className="loginsignup-agree">
          <input type="checkbox" name="" id="" />
          <p>By continuing, i agree to the terms of use & privacy policy.</p>
        </div>
        <button onClick={handleSubmit}>
          {state === "Sign Up" ? "Sign Up" : "Login"}
        </button>
        {state === "Sign Up" ? (
          <p
            className="loginsignup-login"
            style={{ cursor: "pointer" }}
            onClick={() => {
              setState("Login");
            }}
          >
            Already have an account ?<span> Login here</span>
          </p>
        ) : (
          <p
            className="loginsignup-login"
            style={{ cursor: "pointer" }}
            onClick={() => {
              setState("Sign Up");
            }}
          >
            Create an Account ?<span> Click here</span>
          </p>
        )}
        {err && <p id="error">{err}</p>}
      </div>
    </div>
  );
};

export default LoginSignup;
