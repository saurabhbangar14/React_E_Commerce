import React from 'react'
import './DescriptionBox.css'
const DescriptionBox = () => {
  return (
    <div className='descriptinbox'>
      <div className="descriptionbox-navigator">
        <div className="descriptionbox-nav-box">Description</div>
        <div className="descriptionbox-nav-box fade">Reviews (122)</div>
      </div>
      <div className="descriptionbox-description">
        <p>A sleek and modern temporary message display, designed for seamless integration into any digital interface. Crafted with a minimalist aesthetic, it features a transparent background that blends effortlessly with your app's design. The text is clearly visible, ensuring that important messages are not missed. This temporary message component is highly customizable, allowing you to adjust the duration, color, and text content to match your application's theme. Ideal for providing feedback, alerts, or instructions to users, it enhances the user experience by keeping them informed without interrupting their workflow.</p>
        <p>A sleek and modern temporary message display, designed for seamless integration into any digital interface. Crafted with a minimalist aesthetic, it features a transparent background that blends effortlessly with your app's design. The text is clearly visible, ensuring that important messages are not missed. This temporary message component is highly customizable, allowing you to adjust the duration, color, and text content to match your application's theme. Ideal for providing feedback, alerts, or instructions to users, it enhances the user experience by keeping them informed without interrupting their workflow.</p>
      </div>
    </div>
  )
}

export default DescriptionBox
