import React, { useContext, useState, useEffect } from "react";
import "./CartItems.css";
import { ShopContext } from "../../Context/ShopContext";
import remove_icon from "../Assets/cart_cross_icon.png";
import { Link } from 'react-router-dom'
const CartItems = () => {
  const {
    addToCartInBulk,
    getTotalCartAmount,
    all_product,
    cartItem,
    RemoveFromCart,
  } = useContext(ShopContext);

  // State to manage the display mode of the quantity control for each product
  const [displayMode, setDisplayMode] = useState({});
  // State to hold the current quantity value being edited for each product
  const [currentQuantity, setCurrentQuantity] = useState({});

  // Use useEffect to initialize currentQuantity based on cartItem
  useEffect(() => {
    const initialQuantities = {};
    all_product.forEach((product) => {
      initialQuantities[product.id] = cartItem[product.id] || 0;
    });
    setCurrentQuantity(initialQuantities);
  }, [all_product, cartItem]);

  const handleQuantityChange = (productId) => {
    addToCartInBulk(productId, currentQuantity[productId]);
    setDisplayMode((prevMode) => ({ ...prevMode, [productId]: "button" }));
  };

  const toggleDisplayMode = (productId) => {
    setDisplayMode((prevMode) => ({ ...prevMode, [productId]: "input" }));
    setCurrentQuantity((prevQuantity) => ({
      ...prevQuantity,
      [productId]: cartItem[productId],
    }));
  };
  return (
    <div className="cartitems">
      <div className="cartitems-format-main">
        <p>Products</p>
        <p>Title</p>
        <p>Price</p>
        <p>Quantity</p>
        <p>Total</p>
        <p>Remove</p>
      </div>
      <hr />
      {all_product.map((e) => {
        if (cartItem[e.id] > 0) {
          return (
            <div key={e.id}>
              <div className="cartitems-format cartitems-format-main">
                <Link to={`/product/${e.id}`}>  
                  <img src={`../upload/${e.img}`}  className="carticon-product-icon" alt="" /></Link>
                  <Link to={`/product/${e.id}`} style={{ textDecoration: "none",color:"black" }}> <p>{e.title}</p></Link>
              
                <p>₹{e.new_price}</p>
                {displayMode[e.id] === "button" ? (
                  <button
                    className="cartitems-quantity"
                    onClick={() => toggleDisplayMode(e.id)}
                  >
                    {cartItem[e.id]}
                  </button>
                ) : (
                  <input
                    type="text"
                    className="cartitems-quantity"
                    value={currentQuantity[e.id] || 0}
                    onChange={(event) =>
                      setCurrentQuantity((prevQuantity) => ({
                        ...prevQuantity,
                        [e.id]: parseInt(event.target.value),
                      }))
                    }
                    onBlur={() => handleQuantityChange(e.id)}
                    onFocus={() =>
                      setDisplayMode((prevMode) => ({
                        ...prevMode,
                        [e.id]: "input",
                      }))
                    }
                  />
                )}
                <p>{e.new_price * cartItem[e.id]}</p>
                <img
                  className="cartitems-remove-icon"
                  src={remove_icon}
                  onClick={() => RemoveFromCart(e.id)}
                  alt=""
                />
              </div>
              <hr />
            </div>
          );
        } else {
          return null;
        }
      })}

      <div className="cartitems-down">
        <div className="cartitems-total">
          <h1>Cart Totals</h1>
          <div>
            <div className="cartitems-total-item">
              <p>Subtotal</p>
              <p>₹{getTotalCartAmount()}</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <p>Shipping Fee</p>
              <p>Free</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <h3>Total</h3>
              <h3>₹{getTotalCartAmount()}</h3>
            </div>
          </div>
          <button>PROCEED TO CHECKOUT</button>
        </div>
        <div className="cartitems-promocode">
          <p>If you have a promo code, Enter it here</p>
          <div className="cartitems-promobox">
            <input type="text" placeholder="Promo Code" />
            <button>Submit</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItems;
