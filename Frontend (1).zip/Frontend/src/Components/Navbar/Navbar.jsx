import React, { useContext, useRef, useState } from "react";
import "./Navbar.css";
import logo from "../Assets/logo.png";
import cart_icon from "../Assets/cart_icon.png";
import { Link } from "react-router-dom";
import { ShopContext } from "../../Context/ShopContext";
import { AuthContext } from "../../Context/authContext";
import nav_drowpdown from "../Assets/nav_dropdown.webp";
const Navbar = () => {
  const [menu, setMenu] = useState("shop");
  const { getTotalCartItems } = useContext(ShopContext);
  const {currentUser,logout}=useContext(AuthContext);
  const menuRef = useRef();
  // console.log(currentUser.data.user.username);
  const dropdown_toggle = (e) => {
    menuRef.current.classList.toggle("nav-menu-visible");
    e.target.classList.toggle("open");
  };
  return (
    <div className="navbar">
      <div className="nav-logo">
        <img src={logo} alt="" />
        <Link to="/" onClick={() => {
            setMenu("shop");
          }} style={{ textDecoration: "none" }}>
          <p>SHOPPER</p>
        </Link>
      </div>
      <img className="nav-drop" onClick={dropdown_toggle} src={nav_drowpdown} alt="" />
      <ul ref={menuRef} className="nav-menu">
        <li
          onClick={() => {
            setMenu("shop");
          }}
        >
          <Link style={{ textDecoration: "none" }} to="/">
            Shop
          </Link>
          {menu === "shop" ? <hr /> : <></>}
        </li>
        <li
          onClick={() => {
            setMenu("menus");
          }}
        >
          <Link style={{ textDecoration: "none" }} to="/mens">
            Men
          </Link>
          {menu === "menus" ? <hr /> : <></>}
        </li>
        <li
          onClick={() => {
            setMenu("womens");
          }}
        >
          <Link style={{ textDecoration: "none" }} to="/womens">
            Women
          </Link>
          {menu === "womens" ? <hr /> : <></>}
        </li>
        <li
          onClick={() => {
            setMenu("kids");
          }}
        >
          <Link style={{ textDecoration: "none" }} to="/kids">
            Kids
          </Link>
          {menu === "kids" ? <hr /> : <></>}
        </li>
      </ul>
      <div className="nav-login-cart">
      
      <span id="userNamestyle">{currentUser?.data.user.username}</span>
        <Link style={{ textDecoration: "none" }} to="/cart">
        
          <img
            src={cart_icon}
            alt=""
            onClick={() => {
              setMenu("");
            }}
          />
        </Link>
        <div className="nav-cart-count">{getTotalCartItems()}</div>
        <Link onClick={logout}  to="/login">
          <button
            onClick={() => {
              setMenu("");
            }}
          >
            Logout
          </button>
        </Link>
        
      </div>
    </div>
  );
};

export default Navbar;
