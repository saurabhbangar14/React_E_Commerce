import React, { useContext } from "react";
import { ShopContext } from "../../Context/ShopContext";
const SortDropdown = () => {

    const { updateSortOption } = useContext(ShopContext);

    const handleSort = (sortOption) => {

       updateSortOption(sortOption); 
    };
   
    return (
       <ul className="sort-dropdown">
         <li onClick={() => handleSort("By Name")}>By Name</li>
         <li onClick={() => handleSort("By Low to High")}>By Low to High</li>
         <li onClick={() => handleSort("By High to Low")}>By High to Low</li>
       </ul>
    );
   };
   export default SortDropdown;