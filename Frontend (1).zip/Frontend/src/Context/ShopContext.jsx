import React, { createContext, useEffect, useState } from "react";
//  import all_product from "../Components/Assets/all_product";
import axios from "axios";
export const ShopContext = createContext(null);


const product = async () => {
  try {
     const res = await axios.get(`http://localhost:3000/api/posts`);
     return res.data;
  } catch (err) {
     console.log(err);
  }
 };
 const getDefaultCart = (fetchedProducts) => {
  let cart = {};
  for (let index = 0; index < fetchedProducts[fetchedProducts.length-1].id+1; index++) {
    cart[index] = 0;
    // console.log(index);
  }
  return cart;
};


const ShopContextProvider = (props) => {
  
  const [cartItem, setCartItem] = useState([]);
  const [all_product, setProducts] = useState([]); 

  
 // Call the all_product API when the component mounts
 useEffect(() => {
  const fetchProducts = async () => {
    const fetchedProducts = await product();
    setProducts(fetchedProducts); 
    setCartItem(getDefaultCart(fetchedProducts));
  };

  fetchProducts();
}, []);




  const addToCart = (itemId) => {

    setCartItem((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }));
  };
  const addToCartInBulk = (itemId,num) => {
    setCartItem((prev) => ({ ...prev, [itemId]:num }));
  };
  const RemoveFromCart = (itemId) => {
    setCartItem((prev) => ({ ...prev, [itemId]: prev[itemId] - 1 }));
  };



  const [sortOption, setSortOption] = useState('By Name'); // Default sort option

  const updateSortOption = (newSortOption) => {
  setSortOption(newSortOption);
  };
  const getTotalCartAmount = () => {
    let totalAmount = 0;
    for (const item in cartItem) {
      if (cartItem[item] > 0) {
        let itemInfo = all_product.find(
          (product) => product.id === Number(item)
        );
        totalAmount += itemInfo.new_price * cartItem[item];
      }
    }
    return totalAmount;
  };

  const getTotalCartItems = () => {
    let totalItem = 0;
    for (const item in cartItem) {
      if (cartItem[item] > 0) {
        totalItem += cartItem[item];
      }
    }
    return totalItem;
  };



  // console.log("-=-=-=-=-=-",all_1_products)

  const contextValue = {updateSortOption,
    sortOption,
    addToCartInBulk,
    getTotalCartItems,
    getTotalCartAmount,
    all_product,
    cartItem,
    addToCart,
    RemoveFromCart,
  };

  return (
    <ShopContext.Provider value={contextValue}>
      {props.children}
    </ShopContext.Provider>
  );
};

export default ShopContextProvider;
