import React, { useEffect, useState } from "react";
import "./ListProduct.css";
import axios from "axios";
import cross_icon from "../../assets/cross_icon.png";
import { Link } from "react-router-dom";

const ListProduct = () => {
  const [all_products, setProducts] = useState([]);

  const truncateDescription = (description, maxLength) => {
    if (description.length > maxLength) {
      return description.substring(0, maxLength) + "...";
    }
    return description;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`http://localhost:3000/api/posts/`);
        setProducts(res.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    try {
      const response = await axios.delete(
        `http://localhost:3000/api/posts/${id}`,
        {
          data: {
            userId: 12,
          },
        }
      );

      if (response.status === 200 || response.status === 204) {
        console.log("Deletion successful");
        setProducts(all_products.filter((product) => product.id !== id));
      } else {
        console.log("Deletion failed with status code:", response.status);
      }
    } catch (err) {
      console.log("Error during deletion:", err);
    }
  };
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="list-product">
      <div className="sreachProduct">
        <h1>All Products List</h1>
        <input
          type="text"
          placeholder="Search products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-box"
        />
      </div>
      <div className="listproduct-format-main">
        <p>Products</p>
        <p>Title</p>
        <p>Old Price</p>
        <p>New Price</p>
        <p>Category</p>
        <p>Discription</p>
        <p>Remove</p>
      </div>
      <div className="listproduct-allproducts">
        <hr />
        {all_products.filter(
          (product) =>
            product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.description
              .toLowerCase()
              .includes(searchTerm.toLowerCase()) ||
            product.cat.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.old_price.toString().includes(searchTerm) ||
            product.new_price.toString().includes(searchTerm)
        ).length === 0 ? (
          <p>Product Is Not Present</p>
        ) : (
          all_products
            .filter(
              (product) =>
                product.title
                  .toLowerCase()
                  .includes(searchTerm.toLowerCase()) ||
                product.description
                  .toLowerCase()
                  .includes(searchTerm.toLowerCase()) ||
                product.cat.toLowerCase().includes(searchTerm.toLowerCase()) ||
                product.old_price.toString().includes(searchTerm) ||
                product.new_price.toString().includes(searchTerm)
            )
            .map((product) => (
              <React.Fragment key={product.id}>
                <div className="listproduct-format-main listproduct-format">
                  <img
                    src={`http://localhost:3001/upload/${product.img}`}
                    alt=""
                    className="listproduct-product-icon"
                  />
                  <Link to={`/editproduct/${product.id}`} style={{ textDecoration: "none",color:"black" }}>
                    <p>{product.title}</p>
                  </Link>
                  <p>₹ {product.old_price}</p>
                  <p>₹ {product.new_price}</p>
                  <p>{product.cat}</p>
                  <p>{truncateDescription(product.description, 20)}</p>
                  <img
                    src={cross_icon}
                    alt=""
                    className="listproduct-remove-icon"
                    onClick={() => handleDelete(product.id)}
                  />
                </div>
                <hr />
              </React.Fragment>
            ))
        )}
      </div>
    </div>
  );
};

export default ListProduct;
