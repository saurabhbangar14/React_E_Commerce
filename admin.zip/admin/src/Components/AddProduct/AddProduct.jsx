import React, { useEffect, useState } from "react";
import "./AddProduct.css";
import upload_area from "../../assets/upload_area.svg";
import moment from "moment";
import axios from "axios";
import { Link, useNavigate, useLocation } from "react-router-dom";
const AddProduct = () => {
  const userId = 12;
  const location = useLocation();
  const [image, setImage] = useState(false);
  const ProductId = location.pathname.split("/")[2];
  const navigate = useNavigate();
  const [flag, setFlag] = useState(false);
  const [imgflag, setImgflag] = useState(false);
  const [productDetails, setProductDetails] = useState({
    title: "",
    img: "",
    cat: "women",
    new_price: "",
    old_price: "",
    description: "",
    avilable: "True",
  });
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(
          `http://localhost:3000/api/posts/${ProductId}`
        );

        setProductDetails(res.data);
        setImage(res.data.img);
      } catch (err) {
        console.log(err);
      }
    };

    if (ProductId) {
      setFlag(true);
      fetchData();
    }
  }, [ProductId]);

  const imageHandler = (e) => {
    const file = e.target.files[0];
    setImage(file); // Set the image state to the File object
    setFlag(false);
    setImgflag(true);
  };

  const changeHandler = (e) => {
    setProductDetails({ ...productDetails, [e.target.name]: e.target.value });
  };

  const upload = async () => {
    try {
      if (imgflag) {
        const formData = new FormData();
        formData.append("file", image); // image is a File object
        const res = await axios.post(
          "http://localhost:3000/api/uploads",
          formData
        );
        return res.data; // Assuming the response contains the URL of the uploaded image
      } else {
        return image;
      }
    } catch (err) {
      console.log(err);
    }
  };

  const Add_Product = async (e) => {
    e.preventDefault();
    const { title, description, cat, new_price, old_price, avilable } =
      productDetails; // Include new_price and old_price

    if (title.length === 0) {
      alert("Please Enter Title.");
    } else if (description.length === 0) {
      alert("Please Enter Description.");
    } else if (cat.length === 0) {
      alert("Please Select Category.");
    } else if (new_price.length === 0) {
      alert("Please Enter New Price.");
    } else if (old_price.length === 0) {
      alert("Please Enter Old Price.");
    } else {
      const imgUrl = await upload();
      let response = {};
      try {
        ProductId
          ? (response = await axios.put(
              `http://localhost:3000/api/posts/${ProductId}`,
              {
                title,
                desc: description,
                cat,
                img: image ? imgUrl : "",
                userId: userId,
                new_price: Number(new_price),
                old_price: Number(old_price),
                avilable,
              }
            ))
          : (response = await axios.post(`http://localhost:3000/api/posts/`, {
              userId,
              title,
              desc: description,
              cat,
              img: image ? imgUrl : "",
              date: moment(Date.now()).format("YYYY-MM-DD HH:mm:ss"),
              new_price: Number(new_price),
              old_price: Number(old_price),
              avilable,
            }));
        console.log("===", ProductId);

        // if (!ProductId) {
        if (response.status === 200 || response.status === 201) {
          // if (ProductId) {
          //   alert("Product Updated successfully!");
          //   navigate("/listproduct");
          // } else {
          //   alert("Product added successfully!");
          // //              setImage(false);
          // //  setProductDetails({
          // //    title: "",
          // //    img: "",
          // //    cat: "women",
          // //    new_price: "",
          // //    old_price: "",
          // //    description: "",
          // //    avilable: "True"
          // //  });
          // }

        } else {
          console.log("Error:", response.status);
          alert("An error occurred while adding the product."); // Show an error alert
        }
        // } else {

        // }
      } catch (err) {
        console.log(err);
        console.log("Error:", response.status);
        alert("An error occurred while adding the product."); // Show an error alert
      }
    }
  };
  // console.log("==",image);
  return (
    <div className="add-product">
      <div className="addproduct-itemfield">
        <p>Product Name</p>
        <input
          value={productDetails.title} // Changed from productDetails.name to productDetails.title
          onChange={changeHandler}
          type="text"
          name="title" // Ensure this matches the property in your state
          placeholder="Enter Product Name"
        />
      </div>
      <div className="addproduct-price">
        <div className="addproduct-itemfield">
          <p>Price</p>
          <input
            value={productDetails.old_price}
            onChange={changeHandler}
            type="text"
            name="old_price"
            placeholder="Enter Old Product Price"
          />
        </div>
        <div className="addproduct-itemfield">
          <p>Offer Price</p>
          <input
            value={productDetails.new_price}
            onChange={changeHandler}
            type="text"
            name="new_price"
            placeholder="Enter New Product Price"
          />
        </div>
      </div>
      <div className="upload-category">
        <div className="addproduct-itemfield" id="category">
          <p>Product Category</p>
          <select
            value={productDetails.cat}
            onChange={changeHandler}
            name="cat"
            className="add-product-selector"
          >
            <option value="women">Women</option>
            <option value="men">Men</option>
            <option value="kid">Kid</option>
          </select>
        </div>
        <div className="addproduct-itemfield">
          <label htmlFor="file-input">
            <img
              src={
                flag
                  ? `http://localhost:3001/upload/${productDetails.img}`
                  : image
                  ? URL.createObjectURL(image)
                  : upload_area
              }
              className="addproduct-thumnail-img"
            />
          </label>
          <input
            onChange={imageHandler}
            type="file"
            name="image"
            id="file-input"
            hidden
          />
        </div>
      </div>
      <div className="addproduct-itemfield">
        <p>Product Description</p>
        <textarea
          value={productDetails.description}
          onChange={changeHandler}
          name="description"
          placeholder="Enter Product Discription"
          rows="4"
          style={{ width: "auto", resize: "none", padding: "15px" }}
        />
      </div>
      <button onClick={Add_Product} className="addproduct-btn">
        {ProductId ? "UPDATE" : "ADD"}
      </button>
    </div>
  );
};

export default AddProduct;
