
import sql from 'mssql';


export const getPosts = async (req, res) => {
  const request1 = new sql.Request();
  try {

    const query = req.query.cat
      ? `SELECT * FROM blog_posts WHERE cat=@cat`
      : `SELECT * FROM blog_posts`;

    
    if (req.query.cat) {
      request1.input("cat", sql.NVarChar, req.query.cat);
    }

    
    const result = await request1.query(query);

    
    res.status(200).json(result.recordset);
  } catch (err) {
    console.error("Error executing query:", err);
    res.status(500).json({ error: "An error occurred while fetching posts." });
  }
};

export const getPost = async (req, res) => {
  const request1 = new sql.Request();
  try {
    
    const query = `SELECT p.id, u.username, p.title, p.description, p.img,u.img as userImg, p.cat, p.date ,p.new_price,p.old_price,p.avilable
                       FROM blog_users u 
                       JOIN blog_posts p ON u.id = p.uid 
                       WHERE p.id = @postId`;

    
    request1.input("postId", sql.Int, req.params.id);

    
    const result = await request1.query(query);

    console.log(result)
    if (result.recordset && result.recordset.length > 0) {
      
      res.status(200).json(result.recordset[0]);
    } else {
      
      res.status(404).json({ message: "Post not found" });
    }
  } catch (err) {
    console.error("Error executing query:", err);
    res
      .status(500)
      .json({ error: "An error occurred while fetching the post." });
  }
};



export const addPosts = async (req, res) => {
 try {
    
    const query = `INSERT INTO blog_posts(title, description, img, cat, date, uid,old_price,new_price,avilable) VALUES (@title, @desc, @img, @cat, @date, @uid,@old_price, @new_price,@avilable)`;

    
    const request = new sql.Request();

    
    request.input("title", sql.NVarChar, req.body.title);
    request.input("desc", sql.NVarChar, req.body.desc);
    request.input("img", sql.NVarChar, req.body.img);
    request.input("cat", sql.NVarChar, req.body.cat);
    request.input("date", sql.DateTime, req.body.date);
    request.input("uid", sql.Int, req.body.userId);
    request.input("old_price", sql.Int, req.body.old_price);
    request.input("new_price", sql.Int, req.body.new_price);
    request.input("avilable", sql.NVarChar, req.body.avilable);

    
    const result = await request.query(query);

    
    if (result.rowsAffected[0] === 1) {
      return res.status(200).json("Post has been Created.");
    } else {
      return res.status(500).json({ error: "An error occurred while creating the post." });
    }
 } catch (err) {
    console.error("Error executing query:", err);
    return res.status(500).json({ error: "An error occurred while creating the post." });
 }
};




export const deletePosts = async (req, res) => {

    try {
        
        const userId = req.body.userId;
        const request1 = new sql.Request();
        const postId = req.params.id;
        const query = `DELETE FROM blog_posts WHERE id=@postId AND uid=@userId`;
        request1.input('postId', sql.Int, postId);
        request1.input('userId', sql.Int, userId);

        const result = await request1.query(query);

        if (result.rowsAffected[0] === 0) {
            return res.status(403).json("You can delete only your post!");
        }

        return res.json("Post has been deleted!");
    } catch (err) {
      
        return res.status(500).json({ error: "An error occurred while deleting the post." });
    }
};




export const updatePosts = async (req, res) => {
 try {

  
    const query = `UPDATE blog_posts SET title = @title, description = @desc, img = @img, cat = @cat,old_price=@old_price,new_price=@new_price,avilable=@avilable WHERE id = @id AND uid=@uid`;


    const request = new sql.Request();


    request.input("title", sql.NVarChar, req.body.title);
    request.input("desc", sql.NVarChar, req.body.desc);
    request.input("img", sql.NVarChar, req.body.img);
    request.input("cat", sql.NVarChar, req.body.cat);
    request.input("uid", sql.Int, req.body.userId);
    request.input("id", sql.Int, req.params.id); 
    request.input("old_price", sql.Int, req.body.old_price); 
    request.input("new_price", sql.Int, req.body.new_price); 
    request.input("avilable", sql.NVarChar, req.body.avilable);


    const result = await request.query(query);


    if (result.rowsAffected[0] === 1) {
      return res.status(200).json("Post has been updated.");
    } else {
      return res.status(404).json({ error: "Post not found or no changes made." });
    }
 } catch (err) {
    console.error("Error executing query:", err);
    return res.status(500).json({ error: "An error occurred while updating the post." });
 }
};
