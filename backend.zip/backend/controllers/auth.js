import sql from 'mssql';
import jwt from 'jsonwebtoken';
export const register = async (req, res) => {
    const { email, username, password } = req.body; 
    

    const request1 = new sql.Request();
    try {
        
        const query = `SELECT * FROM blog_users WHERE email=@email OR username=@username`;
        request1.input('email', sql.NVarChar, email);
        request1.input('username', sql.NVarChar, username);
        const result = await request1.query(query);

        if (result.recordset && result.recordset.length) {
            
            res.status(409).json({ message: "User already exists" });
        } else {
            
            const query1 = `INSERT INTO blog_users (username, email, password,img) VALUES (@username, @email, @password,@img)`;
            request1.input('password', sql.NVarChar, password); 
            request1.input('img', sql.NVarChar, req.body.imgUrl); 

            await request1.query(query1);
            res.status(200).send("User added successfully");
        }
    } catch (err) {
    
        res.status(500).json({ error: "An error occurred while checking for the user." });
    }
};


export const login = async (req, res) => {
    const { username, password } = req.body; 

    const request1 = new sql.Request();
    try {
        const query = `SELECT * FROM blog_users WHERE username=@username AND password=@password`;
        request1.input('username', sql.NVarChar, username);
        request1.input('password', sql.NVarChar, password);
        const result = await request1.query(query);
            console.log("=====",result);
        if (result.recordset && result.recordset.length) {
            const token = jwt.sign({ id: result.recordset[0].id }, "jwtkey");
            const { password, ...other } = result.recordset[0]; 

            res.status(200).cookie("access_token", token, { httpOnly: true, domain: '.localhost' }).json({
                message: "Login successful",
                user: other
            });
        } else {
            res.status(401).json({ message: "Invalid username or password" });
        }
    } catch (err) {
        console.error("Error executing query:", err);
        res.status(500).json({ error: "An error occurred while logging in." });
    }
};



export const logout = (req, res) => {
    
    res.clearCookie("access_token",{sameSite:"none",secure:true}).status(200).json("User has been logged out.")
};
