import express from 'express';
import sql from 'mssql';
import cors from 'cors';
import postRoutes from "./routes/posts.js";
import userRoutes from "./routes/users.js";
import authRoutes from "./routes/auth.js";
import cookieParser from "cookie-parser";
import multer from "multer";
import { fileURLToPath } from 'url'; // Import fileURLToPath from 'url'
import path from 'path'; // Import path module

const app = express();

app.use(cookieParser());
app.use(express.json());

const corsOptions = {
    origin: [
        'http://localhost:3001', // Your frontend application
        'http://localhost:5173', // Another frontend application

    ],
    credentials: true,
};


app.use(cors(corsOptions));

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        // Use fileURLToPath and path.dirname to get the current module's directory
        const __dirname = path.dirname(fileURLToPath(import.meta.url));
        cb(null, path.join(__dirname, '../frontend/public/upload')); // Adjusted path
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Preserve file extension
    }
});

const upload = multer({ storage });

app.post("/api/uploads", upload.single("file"), function (req, res) {
    const file = req.file;
    res.status(200).json(file.filename);
});

// Serve static files from the specified directory
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use('/upload', express.static(path.join(__dirname, '../frontend/public/upload')));

app.use("/api/posts", postRoutes);
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);

var config = {
    user: "traineeuser",
    password: "Tra!nee$0107",
    server: "10.20.50.117",
    database: "TraineeData",
    options: {
        encrypt: false,
    },
};

// Connect to SQL Server with error handling
sql.connect(config, (err) => {
    if (err) {
        console.error('Database connection error:', err);
        return;
    }
    console.log("Connection Successful!");
});

app.listen(3000, () => {
    console.log("Listening on port 3000...");
});
