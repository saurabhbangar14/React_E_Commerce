import express from "express";
import {updatePosts,deletePosts,addPosts,getPost,getPosts} from "../controllers/post.js"
const router = express.Router()

router.get("/",getPosts)
router.get("/:id",getPost)
router.post("/",addPosts)
router.delete("/:id",deletePosts)
router.put("/:id",updatePosts)


export default router